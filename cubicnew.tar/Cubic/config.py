#Токен бота
token = "1477546630:AAHn8rucC0BkhZjcn6H7tbE2P8QgTNFCKSg"
#ID админов
admins_id = [1152773131]
#Бонус
welcome_bonus = 15.0
#Название бота
bot_name = "KybikNeNaeb_bot"
#Номер киви
qiwi_num = "+380637452538"
#Апи
qiwi_api = "799e9d3a2e8cf0a8bd2c504f1378b65b"
apibtc = ""
#Помощь dice
dice_help = "Помощь"
#Игровая коммисиия
games_comission = 5
#Комиссия на вывод
withdraw_comission = 2
#Ссылка на чат
chat_link = "https://t.me/joinchat/P0UIWhFDh4Q6qgckLOG05Q"
#Ссылка на канал с отзывами
votes_link = "https://t.me/joinchat/RLXsCxnMY6G4zxFfh9-6uA"
#Правила бота
rules_bot = "Правила бота"
#Минимальная сумма ставки
min_sum_bet = 10
#Максимальная сумма ставки
max_sum_bet = 15000
#ID чатов для отправки уведомлений о играх
chats_ids = [385773988]
